import Foundation

//variables for an event object
var timeString = ""
var locationString = ""
var descriptionString = ""
